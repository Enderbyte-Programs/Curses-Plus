# Curses Plus
Extension library to ncurses

## How To Install
Use ```pip3 install cursesplus```
on Linux

### SPECIAL INSTRUCTIONS FOR WINDOWS
For Windows you need to also install ```windows-curses```
to provide the basic curses functionality

## Uses

curses-plus offers many utilities to make writing TUI applications easy. (TUI stands for Terminal User Interface)

### load_colours(grayscale=False)

load_colours() accept 0-1 args and initializes some colours. Usage of this function is required for optionmenu.
grayscale denotes if only grayscale should be used (grayscale can improve visibility on Windows)


*If I have more time I will finish this blasted documentation*