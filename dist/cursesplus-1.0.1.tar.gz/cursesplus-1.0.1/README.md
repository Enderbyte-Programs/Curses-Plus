# Curses Plus
Extension library to ncurses

## How To Install
Use ```pip3 install cursesplus```
on Linux

### SPECIAL INSTRUCTIONS FOR WINDOWS
For Windows you need to also install ```windows-curses```
to provide the basic curses functionality

## Uses

TODO write this
